if !pcall(require,"pk_pills") then
	if SERVER then
		hook.Add("PlayerInitialSpawn","pk_pill_extfail_scp173_cl",function(ply)
			if game.SinglePlayer() || ply:IsListenServerHost() then
				ply:SendLua([[notification.AddLegacy("SCP-173 failed to load. Did you forget to install Parakeet's Pill Pack?",NOTIFY_ERROR,30)]])
			end
		end)
		hook.Add("Initialize","pk_pill_extfail_scp173_sv",function()
			print("[ALERT] SCP-173 pillow extension failed to load. Did you forget to install Parakeet's Pill Pack?")
		end)
	end
	return
end
AddCSLuaFile()
AddCSLuaFile("include/scp173.lua")
include("include/scp173.lua")
local function IsScp173Active(ply)
	if not IsValid(ply) then return nil end
	local ent = pk_pills.getMappedEnt(ply)
	if not IsValid(ent) or ent:GetClass() ~= "pill_ent_costume" then return nil end
	if ent:GetPillUser() ~= ply then return nil end
	if ent:GetPillForm() ~= "scp173" then return nil end
	if pk_pills.getPillTable("scp173") ~= ent.formTable then return nil end
	return ent
end
local function Scp173Exit(ply)
	if not IsValid(ply) then return end
	ply:Freeze(false)
	ply:SetRunSpeed(320)
	ply:SetWalkSpeed(200)
	ply:SetNWBool("Scp173Rush", false)
	ply:SetNWFloat("Scp173RushCd", 0)
	ply:SetNWFloat("Scp173RushStaggerUntil", 0)
	ply:SetNWFloat("Scp173SenseUntil", 0)
	ply:SetNWFloat("Scp173SenseCd", 0)
	timer.Remove("Scp173Rush_" .. ply:EntIndex())
	ply.scp173RunSpeed = nil
	ply:SetNoDraw(false)
	ply:SetRenderMode(RENDERMODE_NORMAL)
	ply:SetColor(Color(255, 255, 255, 255))
end
if SERVER then
	util.AddNetworkString("scp173_sense_self")
	util.AddNetworkString("scp173_sense_scare")
	util.AddNetworkString("scp173_sense_esp")
	util.AddNetworkString("scp173_stalk_fear")
	util.PrecacheModel("models/scp/scp173.mdl")
	hook.Add("Think", "SCP173_Drive", function()
		local scpForm = pk_pills.getPillTable("scp173")
		local seen = {}
		for _, ent in ipairs(ents.FindByClass("pill_ent_costume")) do
			if not IsValid(ent) then continue end
			if not ent.formTable then continue end
			if scpForm ~= ent.formTable then continue end
			local ply = ent:GetPillUser()
			if IsValid(ply) then
				seen[ply:EntIndex()] = true
				if not ply.scp173Active then ply.scp173Active = true end
				ent:SetNoDraw(false)
				local puppet = (ent.GetPuppet and ent:GetPuppet()) or ent.puppet
				if IsValid(puppet) then
					puppet:SetNoDraw(false)
				end
				SCP173Think(ply, ent)
				if not ent:GetNWBool("ScpWatchers", false) and ply:GetVelocity():LengthSqr() > 2500 then
					local now = CurTime()
					if (ent.nextStalkNotify or 0) < now then
						ent.nextStalkNotify = now + 1.2
						for _, vic in ipairs(player.GetAll()) do
							if IsValid(vic) and vic ~= ply and vic:Alive() and vic:GetPos():DistToSqr(ply:GetPos()) < 122500 then
								net.Start("scp173_stalk_fear")
								net.Send(vic)
							end
						end
					end
				end
			end
		end
		for _, ply in ipairs(player.GetAll()) do
			if not IsValid(ply) then continue end
			if ply.scp173Active and not seen[ply:EntIndex()] then
				ply.scp173Active = nil
				Scp173Exit(ply)
			end
		end
	end)
	hook.Add("SetupMove", "SCP173_MoveSpeedDriver", function(ply, mv, cmd)
		local ent = IsScp173Active(ply)
		if not IsValid(ent) then return end
		if ent.scp173RushActive then return end
		local runSpeed = ply.scp173RunSpeed or 320
		if mv:GetForwardSpeed() > 0 or mv:GetSideSpeed() ~= 0 then
			mv:SetMaxSpeed(runSpeed)
			mv:SetMaxClientSpeed(runSpeed)
		end
	end)
	hook.Add("PlayerButtonDown", "SCP173_RushKey", function(ply, key)
		if key ~= KEY_R then return end
		if not IsValid(ply) then return end
		local ent = IsScp173Active(ply)
		if not ent then return end
		if ent.scp173RushActive then return end
		local cdUntil = ent.scp173RushCd or 0
		if CurTime() < cdUntil then return end
		local t = pk_pills.getPillTable("scp173")
		if not t or not t.abilities then return end
		for _, ab in ipairs(t.abilities) do
			if ab.key == KEY_R and ab.func then
				ab.func(ply, ent)
				return
			end
		end
	end)
	hook.Add("PlayerButtonDown", "SCP173_SenseKey", function(ply, key)
		if key ~= KEY_T then return end
		if not IsValid(ply) then return end
		local ent = IsScp173Active(ply)
		if not ent then return end
		if ent.scp173RushActive then return end
		local cdUntil = ent.scp173SenseCd or 0
		if CurTime() < cdUntil then return end
		local t = pk_pills.getPillTable("scp173")
		if not t or not t.abilities then return end
		for _, ab in ipairs(t.abilities) do
			if ab.key == KEY_T and ab.func then
				ab.func(ply, ent)
				ent.scp173SenseCd = CurTime() + (ab.cooldown or 25)
				ply:SetNWFloat("Scp173SenseCd", ent.scp173SenseCd)
				return
			end
		end
	end)
	hook.Add("PlayerButtonDown", "SCP173_MeleeKill", function(ply, key)
		if key ~= MOUSE1 then return end
		if not IsValid(ply) then return end
		if type(SCP173_InstaKill) ~= "function" then return end
		local ent = pk_pills.getMappedEnt(ply)
		if not IsValid(ent) or ent:GetClass() ~= "pill_ent_costume" then return end
		local form = ent:GetPillForm()
		if form ~= "scp173" and form ~= "rgicon" then return end
		if ent:GetPillUser() ~= ply then return end
		local RANGE = 120
		local killed = {}
		for _, v in pairs(ents.FindInSphere(ent:GetPos(), RANGE)) do
			if not IsValid(v) then continue end
			if v == ply then continue end
			if not v:IsPlayer() and not v:IsNPC() then continue end
			local alive = v:IsPlayer() and v:Alive() or (v:IsNPC() and v:Health() > 0)
			if not alive then continue end
			if killed[v:EntIndex()] then continue end
			killed[v:EntIndex()] = true
			SCP173_InstaKill(v, ply)
			if IsValid(v) then
				v:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav")
			end
		end
		local tr = util.TraceLine({
			start  = ply:EyePos(),
			endpos = ply:EyePos() + ply:GetAimVector() * RANGE,
			filter = ply,
			mask   = MASK_SHOT,
		})
		if IsValid(tr.Entity) and not killed[tr.Entity:EntIndex()] then
			local te = tr.Entity
			if (te:IsPlayer() or te:IsNPC()) and te ~= ply then
				local alive = te:IsPlayer() and te:Alive() or (te:IsNPC() and te:Health() > 0)
				if alive then
					SCP173_InstaKill(te, ply)
					if IsValid(te) then
						te:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav")
					end
				end
			end
		end
	end)
	hook.Add("OnEntityRemoved", "SCP173_Cleanup", function(ent)
		if ent:GetClass() ~= "pill_ent_costume" then return end
		if not ent.formTable then return end
		if pk_pills.getPillTable("scp173") ~= ent.formTable then return end
		local ply = ent:GetPillUser()
		if IsValid(ply) then
			ply.scp173Active = nil
			Scp173Exit(ply)
		end
	end)
	local RG_FORM = "rgicon"
	local function IsRGActive(ply)
		if not IsValid(ply) then return nil end
		local ent = pk_pills.getMappedEnt(ply)
		if not IsValid(ent) or ent:GetClass() ~= "pill_ent_costume" then return nil end
		if ent:GetPillUser() ~= ply then return nil end
		if ent:GetPillForm() ~= RG_FORM then return nil end
		if pk_pills.getPillTable(RG_FORM) ~= ent.formTable then return nil end
		return ent
	end
	hook.Add("PlayerButtonDown", "SCP173_RGKey", function(ply, key)
		if key ~= KEY_R and key ~= KEY_T then return end
		if not IsValid(ply) then return end
		local ent = IsRGActive(ply)
		if not ent then return end
		local t = pk_pills.getPillTable(RG_FORM)
		if not t or not t.abilities then return end
		for _, ab in ipairs(t.abilities) do
			if ab.key == key and ab.func then
				local cds = ent.scp173RGCooldowns or {}
				local cdUntil = cds[key] or 0
				if CurTime() < cdUntil then return end
				ab.func(ply, ent)
				cds[key] = CurTime() + (ab.cooldown or 0)
				ent.scp173RGCooldowns = cds
				return
			end
		end
	end)
end
sound.Add({
	name    = "scp173.speed",
	channel = CHAN_USER_BASE + 10,
	volume  = 1.0,
	sound   = { "scp173/speed.wav" }
})
if CLIENT then
	timer.Simple(0, function()
		if type(DrawMaterial) == "function" then
			local oldDraw = DrawMaterial
			function DrawMaterial(mat, ...)
				if not mat then return end
				return oldDraw(mat, ...)
			end
		end
	end)
	local wrappedHooks = {}
	local function WrapAndSuppressBinds()
		for event, hooks in pairs(hook.GetTable()) do
			for name, fn in pairs(hooks) do
				if type(fn) == "function" and not wrappedHooks[fn] then
					local info = debug.getinfo(fn, "S")
					if info and info.short_src and (string.find(info.short_src, "cl_binds") or string.find(info.short_src, "pk_pill")) then
						local originalFn = fn
						local wrapped = function(...)
							local lp = LocalPlayer()
							if IsValid(lp) then
								local ent = pk_pills.getMappedEnt(lp)
								if IsValid(ent) and ent:GetClass() == "pill_ent_costume" and ent:GetPillForm() == "scp173" then
									return
								end
							end
							return originalFn(...)
						end
						wrappedHooks[wrapped] = true
						hooks[name] = wrapped
					end
				end
			end
		end
	end
	timer.Simple(0.5, WrapAndSuppressBinds)
	timer.Simple(2.0, WrapAndSuppressBinds)
	hook.Add("InitPostEntity", "SCP173_SuppressBinds", WrapAndSuppressBinds)
end
sound.Add({
	name    = "scp173.walk",
	channel = CHAN_STATIC,
	volume  = 0.55,
	level   = 75,
	pitch   = 100,
	sound   = {
		"scp173/walksounds/walk1.wav",
		"scp173/walksounds/walk2.wav",
		"scp173/walksounds/walk3.wav"
	}
})
if CLIENT then
	hook.Add("RenderScene", "Scp173ForceDraw", function()
		local scpForm = pk_pills and pk_pills.getPillTable("scp173")
		for _, ent in ipairs(ents.FindByClass("pill_ent_costume")) do
			if IsValid(ent) and (ent:GetPillForm() == "scp173" or (scpForm and ent.formTable == scpForm)) then
				ent:SetNoDraw(false)
				local puppet = (ent.GetPuppet and ent:GetPuppet()) or ent.puppet
				if IsValid(puppet) then
					puppet:SetNoDraw(false)
					puppet:SetRenderMode(RENDERMODE_NORMAL)
					puppet:SetColor(Color(255, 255, 255, 255))
				end
			end
		end
		for _, p in ipairs(player.GetAll()) do
			if IsValid(p) and not (pk_pills and pk_pills.getMappedEnt(p)) then
				if p:GetNoDraw() then
					p:SetNoDraw(false)
					p:SetRenderMode(RENDERMODE_NORMAL)
					p:SetColor(Color(255, 255, 255, 255))
				end
			end
		end
	end)
	local senseVictims = {}
	local senseUntil   = 0
	net.Receive("scp173_sense_self", function()
		local lp = LocalPlayer()
		if IsValid(lp) then lp:EmitSound("scp173/showhighlight.wav") end
	end)
	net.Receive("scp173_sense_scare", function()
		local lp = LocalPlayer()
		if IsValid(lp) then lp:EmitSound("scp173/scare1.wav") end
	end)
	net.Receive("scp173_sense_esp", function()
		local dur = net.ReadFloat()
		senseUntil = CurTime() + dur
		local n = net.ReadUInt(8)
		senseVictims = {}
		for i = 1, n do
			local v = net.ReadEntity()
			if IsValid(v) then senseVictims[#senseVictims + 1] = v end
		end
	end)
	local stalkFearUntil = 0
	net.Receive("scp173_stalk_fear", function()
		stalkFearUntil = CurTime() + 1.5
		local lp = LocalPlayer()
		if IsValid(lp) and lp:Alive() then
			lp:EmitSound("player/heartbeat1.wav", 55, math.random(85, 95), 0.45)
		end
	end)
	hook.Add("HUDPaint", "Scp173StalkDread", function()
		local now = CurTime()
		if now > stalkFearUntil then return end
		local alpha = math.Clamp((stalkFearUntil - now) / 1.5, 0, 1) * 160
		local pulse = alpha * (0.8 + 0.2 * math.sin(now * 8))
		local w, h = ScrW(), ScrH()
		surface.SetDrawColor(15, 0, 0, math.floor(pulse))
		surface.DrawRect(0, 0, w, 24)
		surface.DrawRect(0, h - 24, w, 24)
		surface.DrawRect(0, 0, 24, h)
		surface.DrawRect(w - 24, 0, 24, h)
	end)
	hook.Add("PreDrawHalos", "Scp173SenseHalo", function()
		if CurTime() > senseUntil then return end
		local lp = LocalPlayer()
		if not IsValid(lp) then return end
		if not pk_pills.getPillTable("scp173") then return end
		local targets = {}
		for _, v in ipairs(senseVictims) do
			if IsValid(v) then
				local alive = v:IsPlayer() and v:Alive() or (v:IsNPC() and v:Health() > 0)
				if alive then
					targets[#targets + 1] = v
				end
			end
		end
		if #targets > 0 then
			halo.Add(targets, Color(255, 30, 30), 4, 4, 3, true, true)
		end
	end)
	hook.Add("HUDPaint", "Scp173SenseTags", function()
		if CurTime() > senseUntil then
			if #senseVictims > 0 then senseVictims = {} end
			return
		end
		local lp = LocalPlayer()
		if not IsValid(lp) then return end
		for _, v in ipairs(senseVictims) do
			if not IsValid(v) then continue end
			local alive = v:IsPlayer() and v:Alive() or (v:IsNPC() and v:Health() > 0)
			if not alive then continue end
			local headPos = v:GetPos() + Vector(0, 0, v:IsPlayer() and 75 or 60)
			local scr = headPos:ToScreen()
			if not scr.visible then continue end
			local label = v:IsPlayer() and v:Nick() or (v:GetClass() or "NPC")
			local dist  = math.floor(lp:GetPos():Distance(v:GetPos()))
			draw.SimpleText(label .. " [" .. dist .. "u]", "DermaDefaultBold", scr.x, scr.y - 12, Color(255, 120, 120, 240), TEXT_ALIGN_CENTER, TEXT_ALIGN_BOTTOM)
		end
	end)
	local SpeedMat = Material("speed.png", "smooth")
	local SenseMat = Material("highlight.png", "smooth")
	local function DrawSweepOverlay(cx, cy, r, fraction, col)
		if fraction <= 0 then return end
		local segs = 40
		local sweep = (1 - fraction) * math.pi * 2
		local startAng = -math.pi / 2
		surface.SetDrawColor(col.r, col.g, col.b, col.a)
		for i = 0, segs - 1 do
			local t1 = i / segs
			local t2 = (i + 1) / segs
			local full = math.pi * 2
			local a1 = startAng + t1 * full
			local a2 = startAng + t2 * full
			local segMid = startAng + ((t1 + t2) / 2) * full
			local rel = (segMid - startAng) % (math.pi * 2)
			if rel > sweep then
				local x1 = cx + math.cos(a1) * r
				local y1 = cy + math.sin(a1) * r
				local x2 = cx + math.cos(a2) * r
				local y2 = cy + math.sin(a2) * r
				surface.DrawLine(cx, cy, x1, y1)
				surface.DrawLine(cx, cy, x2, y2)
				surface.DrawLine(x1, y1, x2, y2)
			end
		end
	end
	local function DrawAbilitySlot(x, y, size, mat, cdRemaining, cdTotal, isActive, label, keyHint)
		local cx = x + size / 2
		local cy = y + size / 2
		local r  = size / 2
		draw.RoundedBox(size / 2, x - 4, y - 4, size + 8, size + 8, Color(10, 10, 15, 200))
		local tint = isActive and 255 or (cdRemaining > 0 and 130 or 230)
		surface.SetDrawColor(tint, tint, tint, 255)
		surface.SetMaterial(mat)
		surface.DrawTexturedRect(x, y, size, size)
		if cdRemaining > 0 and cdTotal > 0 then
			local fraction = cdRemaining / cdTotal
			local segs = 48
			local startAng = -math.pi / 2
			local full     = math.pi * 2
			local ready    = (1 - fraction) * full
			for i = 0, segs - 1 do
				local t1 = i / segs
				local t2 = (i + 1) / segs
				local a1 = startAng + t1 * full
				local a2 = startAng + t2 * full
				local midRel = ((t1 + t2) / 2) * full
				if midRel > ready then
					surface.SetDrawColor(0, 0, 0, 180)
					local poly = {
						{ x = cx,                          y = cy                         },
						{ x = cx + math.cos(a1) * r * 1.05, y = cy + math.sin(a1) * r * 1.05 },
						{ x = cx + math.cos(a2) * r * 1.05, y = cy + math.sin(a2) * r * 1.05 },
					}
					draw.NoTexture()
					surface.DrawPoly(poly)
				end
			end
			local edgeAng = startAng + (1 - fraction) * full
			surface.SetDrawColor(255, 60, 60, 230)
			surface.DrawLine(cx, cy,
				cx + math.cos(edgeAng) * r,
				cy + math.sin(edgeAng) * r)
			draw.SimpleText(
				string.format("%.1f", cdRemaining),
				"DermaLarge",
				cx, cy,
				Color(255, 255, 255, 240),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER
			)
		end
		if isActive then
			local pulse = 180 + math.floor(75 * math.sin(CurTime() * 8))
			for i = 1, 3 do
				surface.SetDrawColor(255, 60, 60, math.floor(pulse / i))
				surface.DrawOutlinedRect(x - i, y - i, size + i * 2, size + i * 2, 1)
			end
		end
		draw.RoundedBox(4, x + size - 18, y + size - 18, 18, 18, Color(0, 0, 0, 200))
		draw.SimpleText(keyHint, "DermaDefaultBold", x + size - 9, y + size - 9,
			Color(200, 200, 200, 230), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		draw.SimpleText(label, "DermaDefault", cx, y + size + 8,
			Color(220, 220, 220, 200), TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
	end
	hook.Add("HUDPaint", "Scp173AbilityHUD", function()
		local lp = LocalPlayer()
		if not IsValid(lp) then return end
		local ent = pk_pills.getMappedEnt(lp)
		if not IsValid(ent) or ent:GetClass() ~= "pill_ent_costume" then return end
		if pk_pills.getPillTable("scp173") ~= ent.formTable then return end
		local now = CurTime()
		local rushActive    = lp:GetNWBool("Scp173Rush", false)
		local rushCdEnd     = lp:GetNWFloat("Scp173RushCd", 0)
		local rushCdLeft    = math.max(rushCdEnd - now, 0)
		local staggerEnd    = lp:GetNWFloat("Scp173RushStaggerUntil", 0)
		local isStaggered   = staggerEnd > now
		local senseCdEnd    = lp:GetNWFloat("Scp173SenseCd", 0)
		local senseCdLeft   = math.max(senseCdEnd - now, 0)
		local senseActive   = (lp:GetNWFloat("Scp173SenseUntil", 0) - now) > 0
		local slotSize = 96
		local gap      = 12
		local totalW   = slotSize * 2 + gap
		local startX   = ScrW() / 2 - totalW / 2
		local baseY    = ScrH() - slotSize - 36
		DrawAbilitySlot(
			startX, baseY, slotSize,
			SpeedMat,
			rushActive and 0 or (isStaggered and (staggerEnd - now) or rushCdLeft),
			rushActive and 0 or (isStaggered and 6 or 60),
			rushActive or isStaggered,
			"Speed Rush",
			"R"
		)
		DrawAbilitySlot(
			startX + slotSize + gap, baseY, slotSize,
			SenseMat,
			senseCdLeft,
			25,
			senseActive,
			"Prey Sense",
			"T"
		)
		if ent:GetNWBool("ScpWatchers", false) then
			local barH = 4
			local red  = math.floor(180 + 75 * math.sin(now * 5))
			surface.SetDrawColor(red, 20, 20, 200)
			surface.DrawRect(0, 0, ScrW(), barH)
			draw.SimpleText("OBSERVED", "DermaDefaultBold",
				ScrW() / 2, barH + 4,
				Color(red, 80, 80, 230),
				TEXT_ALIGN_CENTER, TEXT_ALIGN_TOP)
		end
	end)
end
