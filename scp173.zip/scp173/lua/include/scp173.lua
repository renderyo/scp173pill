if !pcall(require,"pk_pills") then return end
pk_pills.packStart("SCP 173","SCP 173","icon/scp173pack.png")
local SCP173 = {
    NORMAL_WALK = 200,
    NORMAL_RUN  = 320,
    WATCHED_RUN = 190,
    CROUCH      = 130,
    BOOST_MAX   = 300,
    BUILD_TIME  = 9,
    DECAY_TIME  = 2.5,
    RUSH_COOLDOWN      = 60,
    RUSH_FREEZE        = 2,
    RUSH_SUFFER_FREEZE = 6,
    RUSH_DURATION      = 15,
    RUSH_LOW           = 400,
    RUSH_START_CAP     = 500,
    RUSH_FINAL_CAP     = 1000,
    RUSH_CAP_GROW      = 10,
    RUSH_BUILD_TIME    = 3.5,
    RUSH_DECAY         = 1.0,
    RUSH_TOUCH_RADIUS  = 110,
    SENSE_DURATION   = 8,
    SENSE_COOLDOWN   = 25,
    SENSE_SPEED_MULT = 1.6,
    SENSE_RANGE      = 4096,
}
function SCP173_InstaKill(t, attacker)
    if not IsValid(t) then return end
    if not t:IsPlayer() and not t:IsNPC() then return end
    local att = IsValid(attacker) and attacker or t
    if t:IsPlayer() then
        pcall(function()
            t:ViewPunch(Angle(math.random(15, 25), math.random(-35, 35), math.random(-15, 15)))
        end)
    end
    pcall(function()
        t:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav", 85, math.random(90, 105))
    end)
    pcall(function()
        if t:IsPlayer() then
            t:GodDisable()
        end
    end)
    pcall(function() if IsValid(t) then t:SetHealth(0) end end)
    pcall(function()
        if IsValid(t) then
            local dmgInfo = DamageInfo()
            dmgInfo:SetDamage(10 ^ 9)
            dmgInfo:SetAttacker(att)
            dmgInfo:SetInflictor(att)
            dmgInfo:SetDamageType(DMG_CRUSH)
            dmgInfo:SetDamageForce(Vector(0, 0, -1))
            t:TakeDamageInfo(dmgInfo)
        end
    end)
    pcall(function()
        if IsValid(t) then
            t:TakeDamage(10 ^ 9, att, att)
        end
    end)
    if IsValid(t) and t:IsPlayer() and t:Alive() then
        pcall(function() if IsValid(t) then t:Kill() end end)
    end
    if IsValid(t) and t:IsNPC() and t:Health() > 0 then
        pcall(function() if IsValid(t) then t:Remove() end end)
    end
    pcall(function() if IsValid(t) then t:SetHealth(0) end end)
end
local function SCP173_BreakDoor(door, attacker)
    if not IsValid(door) then return end
    if door.scp173Broken then return end
    door.scp173Broken = true
    door:SetHealth(0)
    pcall(function() door:TakeDamage(999999, attacker, attacker) end)
    pcall(function()
        if door.Open then door:Open() end
        if door.Toggle then door:Toggle() end
    end)
    timer.Simple(0.05, function()
        if not IsValid(door) then return end
        door:SetSolid(SOLID_NONE)
        door:SetCollisionGroup(COLLISION_GROUP_DEBRIS)
        local phys = door:GetPhysicsObject()
        if IsValid(phys) then
            phys:EnableCollisions(false)
        end
    end)
end
pk_pills.register("scp173",{
    printName = "SCP-173",
    name      = "SCP-173",
    model      = "models/scp/scp173.mdl",
    modelScale = 3.6,
    abilities = {
        {
            name     = "Speed Rush",
            key      = KEY_R,
            cooldown = SCP173.RUSH_COOLDOWN,
            mat      = Material("speed.png", "smooth"),
            icon     = "speed.png",
            func     = function(ply, ent)
                if not IsValid(ply) then return end
                if not IsValid(ent) or ent:GetPillForm() ~= "scp173" then return end
                ply:SetNWBool("Scp173Rush", true)
                ent.scp173RushActive = true
                ent.scp173RushKills  = 0
                ent.scp173RushBuild  = 0
                ent.scp173RushStart  = CurTime()
                ply:Freeze(true)
                ply:EmitSound("scp173.speed")
                ent:PillAnim("jumpscare", true)
                timer.Simple(SCP173.RUSH_FREEZE, function()
                    if not IsValid(ply) then return end
                    ply:Freeze(false)
                    local startTime = CurTime()
                    local duration  = SCP173.RUSH_DURATION
                    local lastGround = true
                    local lastDir    = Vector(0, 0, 0)
                    local killed = {}
                    timer.Create("Scp173Rush_" .. ply:EntIndex(), 0.03, 0, function()
                        if not IsValid(ply) or not ent.scp173RushActive then
                            timer.Remove("Scp173Rush_" .. ply:EntIndex())
                            return
                        end
                        local elapsed = CurTime() - startTime
                        if elapsed >= duration then
                            timer.Remove("Scp173Rush_" .. ply:EntIndex())
                            ent.scp173RushBuild = 0
                            ply:SetNWBool("Scp173Rush", false)
                            ply:SetRunSpeed(SCP173.NORMAL_RUN)
                            ply:SetWalkSpeed(SCP173.NORMAL_WALK)
                            ply:Freeze(true)
                            ply:SetNWFloat("Scp173RushStaggerUntil", CurTime() + SCP173.RUSH_SUFFER_FREEZE)
                            timer.Simple(SCP173.RUSH_SUFFER_FREEZE, function()
                                if not IsValid(ply) then return end
                                ply:Freeze(false)
                                ent.scp173RushActive = false
                                local tf = pk_pills.getPillTable("scp173")
                                local cd = (tf and tf.abilities and tf.abilities[1] and tf.abilities[1].cooldown) or 60
                                ent.scp173RushCd = CurTime() + cd
                                ply:SetNWFloat("Scp173RushCd", ent.scp173RushCd)
                                ply:SetNWFloat("Scp173RushStaggerUntil", 0)
                            end)
                            return
                        end
                        local onGround = ply:OnGround()
                        local jumped   = (lastGround and not onGround) or ply:KeyPressed(IN_JUMP)
                        lastGround = onGround
                        local vel  = ply:GetVelocity()
                        local hvel = Vector(vel.x, vel.y, 0)
                        local speed = hvel:Length()
                        local dir = ply:GetAimVector()
                        dir.z = 0
                        dir:Normalize()
                        local broken = false
                        if jumped then
                            broken = true
                        else
                            local tr = util.TraceLine({
                                start  = ply:EyePos(),
                                endpos = ply:EyePos() + dir * 45,
                                filter = ply,
                                mask   = MASK_SOLID
                            })
                            if tr.Hit and tr.Fraction < 0.7 then
                                broken = true
                            end
                        end
                        if broken then
                            ent.scp173RushBuild = 0
                        elseif onGround and speed > 40 then
                            local dot = 1
                            if lastDir:Length() > 0.5 then
                                dot = lastDir:Dot(dir)
                            end
                            if dot > 0.4 then
                                ent.scp173RushBuild = math.min((ent.scp173RushBuild or 0) + 0.03 / SCP173.RUSH_BUILD_TIME, 1)
                            else
                                ent.scp173RushBuild = math.max((ent.scp173RushBuild or 0) - 0.03 / SCP173.RUSH_DECAY, 0)
                            end
                        else
                            ent.scp173RushBuild = math.max((ent.scp173RushBuild or 0) - 0.03 / SCP173.RUSH_DECAY, 0)
                        end
                        local capGrow    = math.min(elapsed / SCP173.RUSH_CAP_GROW, 1)
                        local currentCap = Lerp(capGrow, SCP173.RUSH_START_CAP, SCP173.RUSH_FINAL_CAP)
                        local rush       = ent.scp173RushBuild or 0
                        local targetSpeed = Lerp(rush, SCP173.RUSH_LOW, currentCap)
                        local kills       = ent.scp173RushKills or 0
                        targetSpeed = targetSpeed * math.max(1 - kills * 0.10, 0.3)
                        local newvel = dir * targetSpeed
                        newvel.z = 0
                        ply:SetVelocity(newvel)
                        lastDir = dir
                        for _, t in ipairs(ents.FindInSphere(ply:GetPos(), SCP173.RUSH_TOUCH_RADIUS)) do
                            if not IsValid(t) then continue end
                            if t == ply then continue end
                            local class  = t:GetClass()
                            local isDoor = (class == "prop_door_rotating" or class == "func_door" or class == "func_door_rotating")
                            if isDoor then
                                SCP173_BreakDoor(t, ply)
                            elseif (t:IsPlayer() or t:IsNPC()) then
                                local hp = t:IsPlayer() and (t:Alive() and t:Health() > 0) or (t:IsNPC() and t:Health() > 0)
                                if hp and not killed[t:EntIndex()] then
                                    killed[t:EntIndex()] = true
                                    SCP173_InstaKill(t, ply)
                                    if IsValid(t) then
                                        t:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav")
                                    end
                                    ent.scp173RushKills = (ent.scp173RushKills or 0) + 1
                                end
                            end
                        end
                        local tr2 = util.TraceLine({
                            start  = ply:GetPos() + Vector(0,0,36),
                            endpos = ply:GetPos() + dir * (SCP173.RUSH_TOUCH_RADIUS + 30) + Vector(0,0,36),
                            filter = ply,
                            mask   = MASK_SHOT,
                        })
                        if IsValid(tr2.Entity) and not killed[tr2.Entity:EntIndex()] then
                            local te = tr2.Entity
                            if (te:IsPlayer() or te:IsNPC()) and te ~= ply then
                                local alive = te:IsPlayer() and te:Alive() or (te:IsNPC() and te:Health() > 0)
                                if alive then
                                    killed[te:EntIndex()] = true
                                    SCP173_InstaKill(te, ply)
                                    if IsValid(te) then
                                        te:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav")
                                    end
                                    ent.scp173RushKills = (ent.scp173RushKills or 0) + 1
                                end
                            end
                        end
                    end)
                end)
            end
        },
        {
            name     = "Prey Sense",
            key      = KEY_T,
            cooldown = SCP173.SENSE_COOLDOWN,
            mat      = Material("highlight.png", "smooth"),
            icon     = "highlight.png",
            func     = function(ply, ent)
                if not IsValid(ply) then return end
                if not IsValid(ent) or ent:GetPillForm() ~= "scp173" then return end
                local dur = SCP173.SENSE_DURATION
                ply:SetRunSpeed(SCP173.NORMAL_RUN * SCP173.SENSE_SPEED_MULT)
                ply:SetWalkSpeed(SCP173.NORMAL_WALK * SCP173.SENSE_SPEED_MULT)
                ent.scp173SenseUntil = CurTime() + dur
                ply:SetNWFloat("Scp173SenseUntil", ent.scp173SenseUntil)
                local function LookingAt(watcher)
                    if not IsValid(watcher) or not watcher:Alive() then return false end
                    local dirTo = (ply:EyePos() - watcher:EyePos())
                    local dist = dirTo:Length()
                    if dist < 1 then return true end
                    if SCP173.SENSE_RANGE > 0 and dist > SCP173.SENSE_RANGE then return false end
                    dirTo:Normalize()
                    local dot = watcher:GetAimVector():Dot(dirTo)
                    if dot < 0.6 then return false end
                    local tr = util.TraceLine({
                        start  = watcher:EyePos(),
                        endpos = ply:EyePos(),
                        filter = { watcher, ply },
                        mask   = MASK_SOLID_BRUSHONLY,
                    })
                    return not tr.Hit
                end
                local victims = {}
                for _, p in ipairs(player.GetAll()) do
                    if not IsValid(p) then continue end
                    if p == ply then continue end
                    if not p:Alive() then continue end
                    local looking = LookingAt(p)
                    victims[#victims + 1] = { ent = p, looking = looking }
                    if not looking then
                        net.Start("scp173_sense_scare")
                        net.Send(p)
                    end
                end
                for _, npc in ipairs(ents.GetAll()) do
                    if not IsValid(npc) then continue end
                    if not npc:IsNPC() then continue end
                    if npc:Health() <= 0 then continue end
                    victims[#victims + 1] = { ent = npc, looking = false }
                end
                net.Start("scp173_sense_self")
                net.Send(ply)
                net.Start("scp173_sense_esp")
                net.WriteFloat(dur)
                net.WriteUInt(#victims, 8)
                for _, v in ipairs(victims) do
                    net.WriteEntity(v.ent)
                end
                net.Send(ply)
                timer.Simple(dur, function()
                    if not IsValid(ply) then return end
                    if CurTime() >= (ent.scp173SenseUntil or 0) then
                        ply:SetRunSpeed(SCP173.NORMAL_RUN)
                        ply:SetWalkSpeed(SCP173.NORMAL_WALK)
                        ply:SetNWFloat("Scp173SenseUntil", 0)
                        ent.scp173SenseUntil = nil
                    end
                end)
            end
        }
    },
    think_SCP173 = function(ply, ent)
        if SERVER then
            local cur = CurTime()
            local watching = false
            local function CanSeeTarget(watcher, targetPlayer, targetEnt)
                if not IsValid(watcher) or not watcher:Alive() then return false end
                if watcher:IsTimedOut() then return false end
                local targetPos = IsValid(targetPlayer) and targetPlayer:EyePos() or (IsValid(targetEnt) and (targetEnt:GetPos() + Vector(0,0,50)) or nil)
                if not targetPos then return false end
                local watcherEye = watcher:EyePos()
                local dirTo = (targetPos - watcherEye)
                local dist = dirTo:Length()
                if dist < 1 then return true end
                dirTo:Normalize()
                local dot = watcher:GetAimVector():Dot(dirTo)
                if dot < 0.50 then return false end
                local tr = util.TraceLine({
                    start  = watcherEye,
                    endpos = targetPos,
                    filter = { watcher, targetPlayer, targetEnt },
                    mask   = MASK_VISIBLE,
                })
                if tr.Hit then
                    return false
                end
                return true
            end
            for _, watcher in ipairs(player.GetAll()) do
                if not IsValid(watcher) then continue end
                if watcher == ply then continue end
                if CanSeeTarget(watcher, ply, ent) then
                    watching = true
                    break
                end
            end
            ent:SetNWBool("ScpWatchers", watching)
            local build      = ent.scp173Build  or 0
            local lastDir    = ent.scp173Dir    or Vector(0, 0, 0)
            local lastGround = ent.scp173Ground ~= false
            local lastTime   = ent.scp173Time   or cur
            local vel    = ply:GetVelocity()
            local hvel   = Vector(vel.x, vel.y, 0)
            local speed  = hvel:Length()
            local onGround = ply:OnGround()
            local dt     = math.Clamp(cur - lastTime, 0, 0.1)
            local jumped = (lastGround and not onGround) or ply:KeyPressed(IN_JUMP)
            local dir = Vector(0, 0, 0)
            if speed > 40 then dir = hvel / speed end
            if jumped then
                build = 0
            elseif onGround and speed > 40 then
                local dot = 1
                if lastDir:Length() > 0.5 then dot = lastDir:Dot(dir) end
                if dot > 0.35 then
                    build = math.min(build + dt / 4.0, 1)
                else
                    build = math.max(build - dt / SCP173.DECAY_TIME, 0)
                end
            else
                build = math.max(build - dt / SCP173.DECAY_TIME, 0)
            end
            ent.scp173Build  = build
            ent.scp173Dir    = dir
            ent.scp173Ground = onGround
            ent.scp173Time   = cur
            local stepClock = (ent.scp173StepClock or 0) + dt
            local stepWait  = math.max(0.25 - build * 0.12, 0.12)
            if onGround and speed > 40 and not ply:IsFrozen() then
                if stepClock >= stepWait then
                    stepClock = 0
                    ply:EmitSound("scp173/walksounds/walk" .. math.random(3) .. ".wav")
                end
            end
            ent.scp173StepClock = stepClock
            local base   = watching and SCP173.WATCHED_RUN or SCP173.NORMAL_RUN
            local run    = base + build * SCP173.BOOST_MAX
            local walk   = math.min(SCP173.NORMAL_WALK, base - 40)
            local crouch = watching and SCP173.CROUCH * 0.5 or SCP173.CROUCH
            ply.scp173RunSpeed = run
            ply:SetRunSpeed(run)
            ply:SetWalkSpeed(walk)
            ply:SetCrouchedWalkSpeed(crouch)
        end
    end,
    moveSpeed = {
        walk   = 200,
        run    = 320,
        ducked = 130,
    },
    sounds = {
        kill      = "scp173/walksounds/walk1.wav",
        freeze    = "scp173/speed.wav",
        jumpscare = "scp173/walksounds/walk1.wav",
        rclick    = "scp173/speed.wav",
    },
    type = "ply",
    camera = { dist = 120 },
    health = 200000,
    movePoseMode = "xy",
    aim = {
        xPose      = "aim_yaw",
        yPose      = "aim_pitch",
        nocrosshair = true
    },
    canAim = function(ply, ent) return true end,
    attack = {
        mode = "trigger",
        func = function(ply, ent)
            local CLICK_RANGE = 100
            local origin = ent:GetPos()
            local found = false
            for _, v in pairs(ents.FindInSphere(origin, CLICK_RANGE)) do
                if not IsValid(v) then continue end
                if v == ply then continue end
                if not v:IsPlayer() and not v:IsNPC() then continue end
                local alive = v:IsPlayer() and v:Alive() or (v:IsNPC() and v:Health() > 0)
                if not alive then continue end
                found = true
                ent:PillAnim("jumpscare", true)
                v:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav")
                SCP173_InstaKill(v, ply)
            end
            if not found then
                local tr = util.TraceLine({
                    start  = ply:EyePos(),
                    endpos = ply:EyePos() + ply:GetAimVector() * CLICK_RANGE,
                    filter = ply,
                    mask   = MASK_SHOT,
                })
                if IsValid(tr.Entity) and (tr.Entity:IsPlayer() or tr.Entity:IsNPC()) and tr.Entity ~= ply then
                    local te = tr.Entity
                    local alive = te:IsPlayer() and te:Alive() or (te:IsNPC() and te:Health() > 0)
                    if alive then
                        ent:PillAnim("jumpscare", true)
                        te:EmitSound("scp173/kill/kill" .. math.random(1, 3) .. ".wav")
                        SCP173_InstaKill(te, ply)
                    end
                end
            end
        end
    },
    attack2 = {
        mode = "trigger",
        func = function(ply, ent) end,
    },
    reload    = function(ply, ent) end,
    flashlight = function(ply, ent) end,
    jump      = function(ply, ent) end,
    anims = {
        default = {
            idle        = "idle",
            walk        = "idle",
            run         = "idle",
            crouch      = "idle",
            crouch_walk = "idle",
            jumpscare   = "idle",
        },
        ShouldMoveRotate  = {},
        ShouldAlternate   = {},
    },
})
SCP173Think = function(ply, ent)
    local t = pk_pills.getPillTable("scp173")
    if t and t.think_SCP173 then
        t.think_SCP173(ply, ent)
    end
end
